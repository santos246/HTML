/**
 * (c) 2018 REINER SCT
 *
 * $Date: Mon Mar 7 13:55:43 2016 +0100$
 * $Rev: 4.2.0$
 */

var RsctOpttanQR = RsctOpttanQR || {};

// Object
// For the initiated application
RsctOpttanQR.opttanApp = null;

// Class
// Js Implementation
RsctOpttanQR.JsOpttan = function (data, device) {
  if (!device) alert('No device given');

  this.data = data;
  this.device = device;

  this.setDevice = function (dev) {
    this.device = dev;
  };

  var html = function () {
    return "<canvas id='rsct-opttan-qr-js-code'></canvas>";
  };

  this.init = function () {
    document.getElementById('rsct-opttan-qr-app').innerHTML = html();
  };

  this.start = function () {
    var dk  = "444B"; // DK
    var ams = "4E"; // N
    var crcdata = dk + ams + data;
    var crc = ("0000" + RsctOpttanQR.Helper.crc16(RsctOpttanQR.Helper.hex2bin(crcdata)).toString(16)).slice(-4);
    var scrambled = RsctOpttanQR.Helper.scramble(ams + data + crc);
    var input = RsctOpttanQR.Helper.hex2bin(dk + scrambled).split("");
    var conv = [];
    input.forEach(function(b) {
      conv.push(b.charCodeAt(0))
    });
    var segs = qrcodegen.QrSegment.makeBytes(conv);
    var eci = qrcodegen.QrSegment.makeEci(1);
    var qr = qrcodegen.QrCode.encodeSegments([eci, segs],
					     qrcodegen.QrCode.Ecc.LOW,
					     4, // min version
					     8, // max version
					     -1, // auto mask selection
					     false);
    var canvas = document.getElementById("rsct-opttan-qr-js-code");
    qr.drawCanvas(100, 4, canvas);
  };
};

// Class
// Opttan Frame Implementation
RsctOpttanQR.Opttan = function (data, opttan_path, type) {
  opttanQRConfig.path = opttan_path;
  opttanQRConfig.imgPath = opttanQRConfig.imgPath ? opttanQRConfig.imgPath : 'images/';
  this.cookie_prefix = opttanQRConfig.cookiePrefix;
  var selected_type = false;
  type = type ? parseInt(type) : 0;
  this.types = ['js'];
  this.app = false;
  this.settings = [];

  this.start = function () {
    var self = this;
    var app = this.app;
    var id = "rsct-opttan-qr-generation";
    RsctOpttanQR.Helper.addClass(document.getElementById(id), "rsct-opttan-running");
    if (app.start) app.start();
    this.stopped = false;
  };

  this.fold = function () {
    var id = "rsct-opttan-qr-generation";
    RsctOpttanQR.Helper.addClass(document.getElementById(id), "rsct-opttan-qr-fold");
    this.setCookie('fold', 1);
  };

  this.unfold = function () {
    var id = "rsct-opttan-qr-generation";
    RsctOpttanQR.Helper.removeClass(document.getElementById(id), "rsct-opttan-qr-fold");
    this.setCookie('fold', 0);
  };

  this.resizeWH = function (newwidth) {
    if (!newwidth) return false;
    //if (!document.getElementById('rsct-opttan-app')) return false;
    if (newwidth < 1) return true;
    if (newwidth > 64) return true;

    newwidth = Math.round(newwidth);

    var device = this.app.device;

    document.getElementById('rsct-opttan-qr-device').className = "rsct-opttan-qr-size-" + newwidth;
    this.setCookie('width_' + device, newwidth);

    return true;
  };

  // hold configuration in own cookie
  // by overwriting cookie_prefix (e.g. for training files)
  // and save to real cookie later
  this.saveCookie = function () {
    var old_prefix = this.cookie_prefix;
    this.cookie_prefix = opttanQRConfig.cookiePrefix;
    this.writeSettings();
    this.cookie_prefix = old_prefix;
  };

  this.resetCookie = function () {
    this.setCookie('width', '');
  };

  this.getWidth = function () {
    var o = document.getElementById('rsct-opttan-qr-device');
    var current = RsctOpttanQR.Helper.classList(o)[0].split("-");
    return parseInt(current[current.length - 1]);
  };

  this.resize = function (step) {
    this.resizeWH(this.getWidth() + step);
  };

  this.setup = function () {
    // setup event handlers
    RsctOpttanQR.Helper.addClickEvent('rsct-opttan-qr-button-larger',  function() {
      RsctOpttanQR.opttanApp.resize(1);
      return false;
    });
    RsctOpttanQR.Helper.addClickEvent('rsct-opttan-qr-button-smaller', function() {
      RsctOpttanQR.opttanApp.resize(-1);
    });

    RsctOpttanQR.Helper.addClickEvent('rsct-opttan-qr-button-fold',    function() {
      RsctOpttanQR.opttanApp.fold();
    });
    RsctOpttanQR.Helper.addClickEvent('rsct-opttan-qr-button-unfold',  function() {
      RsctOpttanQR.opttanApp.unfold();
    });

    var dev = "qr";

    this.app.init();
    this.showDevice(dev, opttanQRConfig.defaultSize);

    if (opttanQRConfig.foldButton) {
      var hide = this.getCookieValue('fold');
      if (hide == 1 || (hide === null && opttanQRConfig.foldOpttanMini)) this.fold();
    }
  };

  this.setCookie = function (key, value, ignore) {
    this.readSettings();
    this.settings[key] = value;
    this.writeSettings();
  };

  this.getCookieValue = function (key) {
    this.readSettings();
    if (this.settings[key])
      return(this.settings[key]);
    else
      return null;
  };

  this.readSettings = function () {
    var settings = '';
    if (opttanQRConfig.userSettingsId && document.getElementById(opttanQRConfig.userSettingsId)) {
      settings = unescape(document.getElementById(opttanQRConfig.userSettingsId).value);
    } else {
      var name = this.cookie_prefix  + "_data";
      var usersettings = typeof(document) != 'undefined' ? document.cookie : '';
      var found = usersettings.indexOf(name + "=");
      if (found > -1) {
        var start =  found + name.length + 1;
        var end = usersettings.indexOf('; ', start);
        if (end == -1) {
          end = usersettings.length;
        }
        settings = unescape(usersettings.substring(start, end));
      }
    }

    if (settings !== "") {
      var temp = settings.split("&");
      for (var i=0; i < temp.length; i++) {
        var t2 = temp[i].split("=");
        this.settings[t2[0]] = t2[1];
      }
    }
  };

  this.writeSettings = function () {
    var strtmp = [];
    for (var key in this.settings) {
      if (key !== "") strtmp.push(key + "=" + this.settings[key]);
    }
    if (opttanQRConfig.userSettingsId && document.getElementById(opttanQRConfig.userSettingsId)) {
      document.getElementById(opttanQRConfig.userSettingsId).value = escape(strtmp.join('&'));
    } else {
      var cookie_string = this.cookie_prefix + "_data=" + escape(strtmp.join('&'));
      if (opttanQRConfig.cookieExpire > 0) {
        var expires = new Date((new Date()).getTime() + 1000 * opttanQRConfig.cookieExpire);
        cookie_string += "; expires=" + expires.toGMTString();
      }
      cookie_string += "; path=/";
      document.cookie = cookie_string;
    }
  };

  this.displayDevice = function (device) {
    if (!device) alert('No device given');
    var app = selectApp(device);
    var out = '<table id="rsct-opttan-qr-generation" class="rsct-' + device + '">';
    out += this.showTitlebar(device);
    out += "<tr id='rsct-opttan-qr-area'>";
    out += "<td><div id='rsct-opttan-qr-device'>";
    out += "<div id='rsct-opttan-qr-app'></div>";
    out += "</div>";
    out += "</td>";
    out += "<td id='rsct-opttan-qr-hint'>";
    out += "<div>" + opttanQRConfig.opttanContent + "</div>";
    out += "</td>";
    out += "</tr>";
    out += "</table>";
    this.app = app;
    return out;
  };

  
  this.showDevice = function (device, size) {
    if (!size) size = 1;
	//document.getElementById('rsct-opttan-qr-generation').className = "rsct-" + device;
    this.app.setDevice(device);

    // reset width and height
    var startSize = 25; //FIXME
    var elem = document.getElementById('rsct-opttan-qr-device');
    elem.className = "rsct-opttan-qr-size-" + startSize;

    if (this.resizeWH((this.getCookieValue('width_' + device) ? this.getCookieValue('width_' + device) : startSize * size)))
      this.start();
  };

  function selectApp(device) {
    if (!device) alert('No device given');
    selected_type = type;
    if (selected_type == 0) return new RsctOpttanQR.JsOpttan(data, device);
    return alert('wrong type:' + type);
  }

  this.showTitlebar = function (device) {
    if (!device) alert('No device given');

    var content = '';
    content += "<tr><td class='rsct-opttan-qr-titlebar' colspan='2'><div class='rsct-opttan-qr-titlebar-inner'>";
    content += "<div id='rsct-opttan-qr-titlebar-right'>";
    if (opttanQRConfig.foldButton) {
      content += "<span id='rsct-opttan-qr-button-fold'>" +
	"<div>" +  opttanQRConfig.text.fold +" </div></span>";
      content += "<span id='rsct-opttan-qr-button-unfold'>" +
	"<div>" + opttanQRConfig.text.fold + "</div></span>";
    }
    content += "</div>";
    content += "<div id='rsct-opttan-qr-titlebar-left'>";
    content += "<span id='rsct-opttan-qr-button-larger'><div>" + opttanQRConfig.text.larger + "</div></span>";
    content += "<span id='rsct-opttan-qr-button-smaller'><div>" + opttanQRConfig.text.smaller+ "</div></span>";
    content += "</div>&nbsp;";
    content += "<div id='rsct-opttan-qr-titlebar-header'>" + opttanQRConfig.opttanHeader + "</div>";
    content += "</div></td></tr>";
    return content;
  };

  this.display = function () {
    return this.displayDevice("qr");
  };

  this.checkCookie = function () {
    this.setCookie('test', true);
    if (!this.getCookieValue('test'))
      alert(opttanQRConfig.text.no_cookie);
  };

};

// Method
// Initialize the opttan application
RsctOpttanQR.init = function (containerId) {
  var container = document.getElementById(containerId);
  if (container) {
    var code = container.getAttribute("data-code");
    var path = container.getAttribute("data-path");
    var type = container.getAttribute("data-type");
    RsctOpttanQR.opttanApp = new RsctOpttanQR.Opttan(code, path, type);
    container.innerHTML = RsctOpttanQR.opttanApp.display();
    RsctOpttanQR.opttanApp.setup();
  }
};

// Class
// JS Helpers
RsctOpttanQR.Helper = function () {

  var c8005 = [0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,
	       0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,
	       0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40,
	       0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
	       0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,
	       0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,
	       0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641,
	       0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,
	       0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240,
	       0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
	       0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41,
	       0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,
	       0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
	       0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,
	       0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,
	       0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,
	       0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240,
	       0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,
	       0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41,
	       0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
	       0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41,
	       0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
	       0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640,
	       0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,
	       0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,
	       0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
	       0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40,
	       0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,
	       0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40,
	       0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
	       0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,
	       0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040];

  var crc16 = function (s) {
    var crc = 0x0000;
    var j, i;

    for (i = 0; i < s.length; i++) {
      c = s.charCodeAt(i);
      if (c > 255) {
	throw new RangeError();
      }
      crc = (crc >> 8) ^ c8005[ (crc ^ c) & 0x00FF ];
    }
    return crc;
  }

  var scramble = function (s) {
    var bytes = RsctOpttanQR.Helper.hex2bin(s);
    var result = "";
    var i;
    for (i = 0; i < bytes.length; i = i + 2) {
      c1 = bytes.charCodeAt(i);
      result += RsctOpttanQR.Helper.toHex(c1 ^ 0x44);
      if (i+1 < bytes.length) {
	c2 = bytes.charCodeAt(i+1);
	result += RsctOpttanQR.Helper.toHex(c2 ^ 0x4b);
      }
    }
    return result;
  }


  var toHex = function (d) {
    return ("0"+(Number(d).toString(16))).slice(-2).toUpperCase();
  }

  var hex2bin = function (text) {
    var i = 0, len = text.length, result = "";

    // Converting the hex string into an escaped string, so if the hex string is "aabbcc", it will become "%aa%bb%cc"
    for(; i < len; i+=2)
      result += '%' + text.substr(i, 2);

    return unescape(result);
  }

  // IE8 Compatibility
  var addEvent = function (elem, f, e) {
    if (elem.addEventListener) {
      elem.addEventListener(e, f);
    } else {
      elem.attachEvent("on" + e, f);
    }
  }

  var addClickEvent = function (id, f) {
    var elem = document.getElementById(id);
    if (!elem) return;
    addEvent(elem, f, "click");
  }

  var addLoadEvent = function (elem, f) {
    addEvent(elem, f, "load");
  }

  var addContentLoadedEvent = function (f) {
    if (document.addEventListener) {
      document.addEventListener("DOMContentLoaded", f);
    } else {
      document.attachEvent("onreadystatechange", f);
    }
  }

  var hasClass = function (node, name) {
    var a = classList(node);
    for (var i = 0; i < a.length; i++) {
        if (a[i] === name) {
            return true;
        }
    }
    return false;
  };

  var classList = function (node) {
	  if(node != null){
    return node.className.split(" ");
	  }
	  return '';
  };

  var addClass = function (node, name) {
	  if(node != null && name != null){
    if (!hasClass(node, name)) {
      node.className = node.className + " " + name;
    }
	  }
  };

  var removeClass = function (node, name) {
    var list = classList(node);
    var newlist = [];
    for (var i = 0; i < list.length; i++) {
        if (list[i] !== name) {
          newlist.push(list[i]);
        }
    }
    node.className = newlist.join(" ");
  };

  var oPublic =
    {
      addClickEvent: addClickEvent,
      addLoadEvent: addLoadEvent,
      addContentLoadedEvent: addContentLoadedEvent,
      hasClass: hasClass,
      classList: classList,
      addClass: addClass,
      removeClass: removeClass,
      hex2bin: hex2bin,
      toHex: toHex,
      scramble: scramble,
      crc16: crc16
    };

  return oPublic;

}();
