/**
 * (c) 2018 REINER SCT
 *
 * $Date: Mon Mar 7 13:55:43 2016 +0100$
 * $Rev: 4.2.0$
 */

var opttanQRConfig = {};
opttanQRConfig.text = {};

/* RSCT Opttan Version */

opttanQRConfig.version = "4_2_0-32-ge6ccec7";

/* Beschreibung f�r das OpticTAN QR Ger�t */

opttanQRConfig.opttanHeader = '';
opttanQRConfig.opttanContent = '<div class="osppinfoinhalt"><ul><li>Stecken Sie Ihre Karte in den TAN-Generator.</li><li>Halten Sie den TAN-Generator vor den QR Code.</li><li>Beachten Sie bitte die Anzeige des TAN-Generators.</li></ul></div>';

/* Ein-/Ausklappen-Knopf anzeigen */

opttanQRConfig.foldButton   = true;

/* OpticTAN Grafik per Vorgabe ein- oder ausklappen */

opttanQRConfig.foldOpttanMini   = false;

/* Kopfzeile "TAN-Generierung" anzeigen */

opttanQRConfig.showHeader = false;

/* Vorgabe Frame-Dauer in ms f�r die opticTAN-Animation */

opttanQRConfig.defaultDelay = 50; // entspricht 20Hz

/* Minimal Frame-Dauer in ms f�r die opticTAN-Animation */

opttanQRConfig.maxDelay = 33; // entspricht 30Hz

/* Vorgabe Gr��enanpassung f�r die opticTAN-Animation */

opttanQRConfig.defaultSize = 0.77;

/* Prefix des Cookies f�r die Speicherung der Benutzereinstellungen */

opttanQRConfig.cookiePrefix = 'opttan_qr';

/* Expire des Cookies f�r Benutzereinstellungen in Sekunden.
   Wenn gleich 0, so wird Cookie am Ende der Session gel�scht */

opttanQRConfig.cookieExpire = 60*60*24*365; // 1 Jahr

/* Optionale Id des Hidden-Feldes f�r Speicherung der Benutzereinstellungen (false = Einstellungen im Cookie speichern) */

opttanQRConfig.userSettingsId = false;

/* Pfad zum Image-Ordner */

opttanQRConfig.imgPath = 'chrome-extension://hjfoakeikoggpfobchjgponlndiggkgf/optictan/rsct_opttan/images/';

/* Button-Texte */

opttanQRConfig.text.header = "TAN-Generierung mit:";
// opttanQRConfig.text.no_cookie = "In Ihrem Browser sind Cookies ausgeschaltet.\nDie Gr&ouml;&szlig;en&auml;nderung kann nur mit eingeschalteten Cookies gespeichert werden.";

opttanQRConfig.text.fold = "Ein / Ausblenden";
opttanQRConfig.text.larger = "Grafik vergr&ouml;&szlig;ern";
opttanQRConfig.text.smaller = "Grafik verkleinern";
